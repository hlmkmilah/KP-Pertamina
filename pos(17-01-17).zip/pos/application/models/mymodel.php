<?php
/**
* 
*/
class Mymodel extends CI_Model
{
	
	public function prosesLogin($email,$pass)
	{
		$this->db->where('email', $email);
		$this->db->where('password', $pass);
		return $this->db->get('user')->row();
		//kalo pake 'where' maka pake 'row'
	}

	public function getTagihanK()
	{
		$data = $this->db->get('tagihankontrak');
		return $data->result_array();
	}

	public function getTagihanNK()
	{
		$data = $this->db->get('tagihannonkontrak');
		return $data->result_array();
	}

	public function getPanjar()
	{
		$data = $this->db->get('panjar');
		return $data->result_array();
	}

	public function getKontrak()
	{
		$data = $this->db->get('kontrak');
		return $data->result_array();
	}

	public function getUser()
	{
		$data = $this->db->get('user');
		return $data->result_array();
	}

	public function getVendor()
	{
		$data = $this->db->get('vendor');
		return $data->result_array();
	}
}