<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>PT. Pertamina MOR V (Persero)</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/assets/css/materialize.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/assets/css/materialize.min.css" media="screen,projection">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/assets/css/login.css">

    <script type="text/javascript" src="<?php echo base_url();?>/assets/js/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>/assets/js/materialize.js"></script>

    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

<body>
	<img src='<?php echo base_url();?>/assets/img/logorenewable.png' width="170">
	<div id="html-menu">
        <b class="spiffy-rounded"><b class="spiffy-rounded1"></b><b class="spiffy-rounded2">
        </b><b class="spiffy-rounded3"></b><b class="spiffy-rounded4"></b><b class="spiffy-rounded5">
        </b></b>
        
        <div class="spiffy-rounded-bottomfg"></div>
        <b class="spiffy-rounded-bottom"><b class="spiffy-rounded-bottom5"></b><b class="spiffy-rounded-bottom4">
        </b><b class="spiffy-rounded-bottom3"></b><b class="spiffy-rounded-bottom2"></b><b class="spiffy-rounded-bottom1"></b></b>
    </div><br>

    <div id="container">
    	<?php echo $this->session->flashdata('err'); ?>
	    <h1><img alt="login" src='<?php echo base_url();?>/assets/img/login.gif'>	Sign In</h1>
	    <div id="body">
	    	<form action="<?php echo site_url('auth/login') ?>" method="POST">
				<input type="text" name="email" placeholder="Email">
				<input type="password" name="password" placeholder="Password">
				<button type="submit" name="submit">Login</button>
			</form>
		</div>
			
	</div>

	<div id="footer" style="position: absolute; bottom: 0px; z-index: 200; width: 100%;">
            <div class="ptmn-line">
                <div class="col-left">
                    <div class="ptmn-red-hr">
                    </div>
                </div>
                <div class="col-middle">
                    <div class="ptmn-green-hr">
                    </div>
                </div>
                <div class="col-right">
                    <div class="ptmn-blue-hr">
                    </div>
                </div>
            </div>
            <div class="left">
                <strong>Corporate Shared Service</strong><br>
                Medan Merdeka Timur St, No. 1 A Jakarta - 10110 INDONESIA<br>
                Annex Building, 1st Floor<br>
                e-mail : <a href="mailto:servicedesk@pertamina.com">Service Desk</a><br>
            </div>
            <div class="right">
                <strong>PT. PERTAMINA (PERSERO)</strong><br>
                Medan Merdeka Timur St, No. 1 A Jakarta - 10110 INDONESIA<br>
                Phone : (+62)(21) 7917 3000 - Fax : (+62)(21) 7972 177<br>
                e-mail : <a href="mailto:pcc@pertamina.com">Pertamina Contact Center</a><br>
            </div>
        </div>
    <div id="footerSpaceManager" style="height: 79px;"></div>

</body>
</html>