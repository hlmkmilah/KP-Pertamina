<!DOCTYPE html>
<html lang="en">
	<head>
        <meta charset="utf-8">
		<title>PT. Pertamina MOR V (Persero)</title>
	    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/assets/css/materialize.css">
	    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/assets/css/materialize.min.css" media="screen,projection">
	    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/assets/css/border.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/assets/css/footer.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/assets/css/home.css">

	    <script type="text/javascript" src='<?php echo base_url();?>/assets/js/jquery.min.js'></script>
	    <script type="text/javascript" src='<?php echo base_url();?>/assets/js/materialize.js'></script>

	    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

        <script>$('document').ready(function(){                
         $(".dropdown-button").dropdown();
         $(".button-collapse").sideNav();
        }
        </script>
        <style>
           body {
              font: 76% Verdana,Tahoma,Arial,Sans-Serif
           }
        </style>
      </head>
	<body>
		<div id="container">
			<img src='<?php echo base_url();?>/assets/img/logo-ptmn.png' style="margin-top: 10px; margin-bottom: 5px;">
			<div class="navbar-fixed" style="margin-top: 0px; padding: 0; height: 40px;">
	          <nav  style="background-color: #da251c; height: 40px; width: 100%; position: relative;">
	             <div class="nav-wrapper">
	                <ul class="left hide-on-med-and-down" style="margin-top: 0px; top: 0px; color: white;">
	                   <li><a class="text" href="homepage.php" style="height: 40px; line-height: 40px; font-family: Verdana; font-size: 10pt;">Beranda</a></li>
	                   <li><a class="text" href="#" style="height: 40px; line-height: 40px; font-family: Verdana; font-size: 10pt;">Kontrak</a></li>
	                   <li><a class="text" href="#" style="height: 40px; line-height: 40px; font-family: Verdana; font-size: 10pt;">Tagihan Kontrak</a></li>
	                   <li><a class="text" href="#" style="height: 40px; line-height: 40px; font-family: Verdana; font-size: 10pt;">Tagihan Non-Kontrak</a></li>
	                   <li><a class="text" href="#" style="height: 40px; line-height: 40px; font-family: Verdana; font-size: 10pt;">Panjar</a></li>
	                   <li><a class="dropdown-button white-text" href="#" data-activates="dropdown1" style="height: 40px; line-height: 40px; font-family: Verdana; font-size: 10pt;">Master Data</a><ul id="dropdown1" class="dropdown-content" style="background-color: #85c226;">
           <li><a href="#!" style="font-family: Verdana; font-size: 10pt; color: white;">Vendor</a></li>
           <li><a href="#!" style="font-family: Verdana; font-size: 10pt; color: white;">User</a></li>
        </ul></li>
	                </ul>
	                <ul class="right hide-on-med-and-down" style="margin-top: 0px; top: 0px; color: white;">
	                  <li><a class="text" href="<?php echo site_url('auth/logout'); ?>" style="height: 40px; line-height: 40px; font-family: Verdana; font-size: 10pt;">Logout</a></li>
	                </ul>
	             </div> <!-- nav-wrapper -->
	          </nav>
	        </div> <!-- navbar-fixed -->
	        
	        <div id="html-menu" style="width: 100%;">
	           <div class="spiffy-rounded-bottomfg" style="margin-top: 3px;">
	           </div>
	           <b class="spiffy-rounded-bottom">
	               <b class="spiffy-rounded-bottom5"></b>
	               <b class="spiffy-rounded-bottom4"></b>
	               <b class="spiffy-rounded-bottom3"></b>
	               <b class="spiffy-rounded-bottom2"></b>
	               <b class="spiffy-rounded-bottom1"></b>
	           </b>
	        </div> <!-- html-menu -->
			<h5>Selamat Datang <?php echo $this->session->userdata('loger'); ?></h5>

			<div id="body">
				<table border="5" cellspacing="0">
					<tr>
						<th>No</th>
						<th>Nama</th>
						<th>Email</th>
					</tr>
						<?php
						$no = 1;
						foreach($hasil as $r){ ?>
					<tr>
						<td><?php echo $no++ ?></td>
						<td><?php echo $r['Nama'] ?></td>
						<td><?php echo $r['Email'] ?></td>
					</tr>
					<?php } ?>
				</table>
			</div>
		</div> <!-- container -->

	</body>
</html>
