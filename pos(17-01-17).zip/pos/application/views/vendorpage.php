<!DOCTYPE html>
  <html lang="en">
    <head>
      <title>PT. Pertamina MOR V (Persero)</title>
      <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/assets/css/materialize.css">
      <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/assets/css/materialize.min.css" media="screen,projection">
      <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/assets/css/border.css">
      <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/assets/css/footer.css">
      <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/assets/css/home.css">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

      <script type="text/javascript" src="<?php echo base_url();?>/assets/js/jquery.min.js"></script>
      <script type="text/javascript" src="<?php echo base_url();?>/assets/js/materialize.js"></script>

      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

      <script>$('document').ready(function(){                
       $(".dropdown-button").dropdown();
       $(".button-collapse").sideNav();
      }
      </script>
      
      <style>
         body {
            font: 76% Verdana,Tahoma,Arial,Sans-Serif
         }
      </style>
    </head>
    
    <body>
      <div id="container">
        <ul id="dropdown1" class="dropdown-content" style="background-color: #85c226; width: 100%;">
           <li><a href="<?php echo site_url('auth/vendorpage'); ?>" style="font-family: Verdana; font-size: 10pt; color: white;"><b>Vendor</b></a></li>
           <li><a href="<?php echo site_url('auth/userpage'); ?>" style="font-family: Verdana; font-size: 10pt; color: white;"><b>User</b></a></li>
        </ul>
        <img src='<?php echo base_url();?>/assets/img/logo-ptmn.png' style="margin-left: 10px; margin-top: 10px; margin-bottom: 5px;">         
        <div class="navbar-fixed" style="margin-top: 0px; padding: 0; height: 40px;">
          <nav  style="background-color: #da251c; height: 40px; width: 100%; position: relative;">
             <div class="nav-wrapper">
                <ul class="left hide-on-med-and-down" style="margin-top: 0px; top: 0px; color: white;">
                  <li>
                    <a class="text" href="<?php echo site_url('auth/homepage'); ?>" style="height: 40px; line-height: 40px; font-family: Verdana; font-size: 10pt;"><b>Beranda</b></a>
                  </li>
                  <li>
                    <a class="text" href="<?php echo site_url('auth/kontrakpage'); ?>" style="height: 40px; line-height: 40px; font-family: Verdana; font-size: 10pt;"><b>Kontrak</b></a>
                  </li>
                  <li>
                    <a class="text" href="<?php echo site_url('auth/tagihankontrakpage'); ?>" style="height: 40px; line-height: 40px; font-family: Verdana; font-size: 10pt;"><b>Tagihan Kontrak</b></a>
                  </li>
                  <li>
                    <a class="text" href="<?php echo site_url('auth/tagihannonkontrakpage'); ?>" style="height: 40px; line-height: 40px; font-family: Verdana; font-size: 10pt;"><b>Tagihan Non-Kontrak</b></a>
                  </li>
                  <li>
                    <a class="text" href="<?php echo site_url('auth/panjarpage'); ?>" style="height: 40px; line-height: 40px; font-family: Verdana; font-size: 10pt;"><b>Panjar</b></a>
                  </li>
                  <li>
                    <a class="dropdown-button white-text" href="#" data-activates="dropdown1" style="height: 40px; line-height: 40px; font-family: Verdana; font-size: 10pt;"><b>Master Data</b></a>
                  </li>
                </ul>
                
                <ul class="right hide-on-med-and-down" style="margin-top: 0px; top: 0px; color: white;">
                  <li>
                    <a class="text" href="<?php echo site_url('auth/logout'); ?>" style="height: 40px; line-height: 40px; font-family: Verdana; font-size: 10pt;"><b>Logout</b></a>
                  </li>
                </ul>
             </div> <!-- nav-wrapper -->
          </nav>
        </div> <!-- navbar-fixed -->
        
        <div id="html-menu" style="width: 100%;">
          <div class="spiffy-rounded-bottomfg" style="margin-top: 3px;"></div>
            <b class="spiffy-rounded-bottom">
              <b class="spiffy-rounded-bottom5"></b>
              <b class="spiffy-rounded-bottom4"></b>
              <b class="spiffy-rounded-bottom3"></b>
              <b class="spiffy-rounded-bottom2"></b>
              <b class="spiffy-rounded-bottom1"></b>
            </b>
        </div> <!-- html-menu -->

        <div class="row">
          <div class="col s12">
            <h5 style="font-family: Verdana; font-size: 12pt;"><b>Data Vendor</h5>
            
            <a href = "#" style="font-family: Verdana; font-size: 10pt;">
              <button class="btn waves-effect" type="submit" name="action" style="height: 30px; background-color: #32599c;">
                <i class="material-icons" style="font-size: 1rem; line-height: 30px; width: 1px;">add</i>
              </button>
            </a>
          </div>
          
          <div class="col s12">
            <div  style="background-color: #e4ece8; width: 100%; min-height: 100px;">
              <table class="highlight centered">
                <thead>
                  <tr>
                    <th data-field="id">Nomor</th>
                    <th data-field="Nama">Nama Vendor</th>
                    <th data-field="ubah"> </th>
                  </tr>
                </thead>
                
                <tbody>
                <?php foreach($hasilVendor as $r){ ?>
                  <tr>
                    <td><?php echo $r['idVendor'] ?></td>
                    <td><?php echo $r['namaVendor'] ?></td>
                    <td>
                      <a href = "#" style="font-family: Verdana; font-size: 10pt;">
                        <button class="btn waves-effect" type="submit" name="action" style="height: 30px; background-color: #85c226; line-height: 30px;">
                          <i class="material-icons" style="font-size: 1rem; line-height: 30px; width: 1px;">edit</i>
                        </button>
                      </a>
                    </td>
                  </tr>
                <?php } ?>
                </tbody>
              </table>
            </div>
          </div> <!-- col s12 -->
        </div> <!-- row -->
        
        <div id="footer" style="position: relative; bottom: 0px; width: 100%;">
          <div class="ptmn-line">
              <div class="col-left">
                  <div class="ptmn-red-hr"></div>
              </div>
              
              <div class="col-middle">
                  <div class="ptmn-green-hr"></div>
              </div>
              
              <div class="col-right">
                  <div class="ptmn-blue-hr"></div>
              </div>
          </div> <!-- ptmn-line -->
          
          <div class="left">
              <strong>Corporate Shared Service</strong><br>
              Medan Merdeka Timur St, No. 1 A Jakarta - 10110 INDONESIA<br>
              Annex Building, 1st Floor<br>
              e-mail : <a href="mailto:servicedesk@pertamina.com">Service Desk</a><br>
          </div>
          
          <div class="right">
              <strong>PT. PERTAMINA (PERSERO)</strong><br>
              Medan Merdeka Timur St, No. 1 A Jakarta - 10110 INDONESIA<br>
              Phone : (+62)(21) 7917 3000 - Fax : (+62)(21) 7972 177<br>
              e-mail : <a href="mailto:pcc@pertamina.com">Pertamina Contact Center</a><br>
          </div>
        </div> <!-- footer -->
 
        <div id="footerSpaceManager" style="height: 79px;"></div>

      </div> <!-- container -->
  </body>
</html>