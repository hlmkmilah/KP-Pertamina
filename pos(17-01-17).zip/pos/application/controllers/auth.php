<?php

class Auth extends CI_Controller
{
	public function index()
	{
		$this->load->view('login');
	}
	
	public function login()
	{
		$email = $this->input->post('email', true);
		$pass = $this->input->post('password', true);
		$cek = $this->mymodel->prosesLogin($email,$pass);
		$hasil = count($cek);
		//echo $hasil;
		if($hasil > 0)
		{
			$select = $this->db->get_where('user', array('email' => $email, 'password' => $pass))->row();
			$data = array('logged_in' => true, 'loger' => $select->Nama); //untuk munculin nama orang yg login
			$this->session->set_userdata($data);
			redirect('auth/homepage');
			//echo "login berhasil";
		}
		else
		{
			$this->session->set_flashdata('err', 'Wrong Email or Password!');
			//$this->load->view('index');
			redirect('auth/index');
			//echo "gagal login";
		}
	}

	public function homepage()
	{
		$dataTagihanK = $this->mymodel->getTagihanK('tagihankontrak');
		if($dataTagihanK){
			$data['hasilTagihanK'] = $dataTagihanK;
		}

		$dataTagihanNK = $this->mymodel->getTagihanNK('tagihannonkontrak');
		if($dataTagihanNK){
			$data['hasilTagihanNK'] = $dataTagihanNK;
		}

		$dataPanjar = $this->mymodel->getPanjar('panjar');
		if($dataPanjar){
			$data['hasilPanjar'] = $dataPanjar;
		}

		$dataKontrak = $this->mymodel->getKontrak('kontrak');
		if($dataKontrak){
			$data['hasilKontrak'] = $dataKontrak;
		}

		$this->load->view('homepage', $data);
	}

	public function kontrakpage()
	{
		$dataKontrak = $this->mymodel->getKontrak('kontrak');
		if($dataKontrak){
			$data['hasilKontrak'] = $dataKontrak;
		}
		$this->load->view('kontrakpage', $data);
	}

	public function tagihankontrakpage()
	{
		$dataTagihanK = $this->mymodel->getTagihanK('tagihankontrak');
		if($dataTagihanK){
			$data['hasilTagihanK'] = $dataTagihanK;
		}
		$this->load->view('tagihankontrakpage', $data);
	}

	public function tagihannonkontrakpage()
	{
		$dataTagihanNK = $this->mymodel->getTagihanNK('tagihannonkontrak');
		if($dataTagihanNK){
			$data['hasilTagihanNK'] = $dataTagihanNK;
		}
		$this->load->view('tagihannonkontrakpage', $data);
	}

	public function panjarpage()
	{
		$dataPanjar = $this->mymodel->getPanjar('panjar');
		if($dataPanjar){
			$data['hasilPanjar'] = $dataPanjar;
		}
		$this->load->view('panjarpage', $data);
	}

	public function userpage()
	{
		$dataUser = $this->mymodel->getUser('user');
		if($dataUser){
			$data['hasilUser'] = $dataUser;
		}
		$this->load->view('userpage', $data);
	}

	public function vendorpage()
	{
		$dataVendor['hasilVendor'] = $this->mymodel->getVendor('vendor');
		$this->load->view('vendorpage', $dataVendor);
	}

	public function logout()
	{
		$this->session->sess_destroy();
		//$this->load->view('index');
		redirect('auth/index');
	}
}