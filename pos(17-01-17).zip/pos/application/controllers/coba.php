<?php
class Coba extends CI_Controller{
function __construct(){
	parent::__construct();
	$this->load->model('mymodel');
}
function index()
{
	$data['title']='ini contoh untuk menampilkan data';
	$data['buku']=$this->mbuku->selectAll();
	$this->load->view('vbuku',$data);
	}
}
?>