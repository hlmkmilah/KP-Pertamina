<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index(){
		$this->$data['data'] = $this->mymodel->coba('tagihankontrak');
		$this->load->view('nyobahome', $this->data);
	}
}
