$(function(){
    $(".chzn-select").chosen();
});