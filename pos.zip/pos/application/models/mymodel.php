<?php
/**
* 
*/
class Mymodel extends CI_Model
{
	
	public function prosesLogin($email,$pass)
	{
		$this->db->where('email', $email);
		$this->db->where('password', $pass);
		return $this->db->get('user')->row();
		//kalo pake 'where' maka pake 'row'
	}

	public function getTagihanK($table)
	{
		$data = $this->db->get($table);
		return $data->result_array();
	}

	public function getTagihanNK($table)
	{
		$data = $this->db->get($table);
		return $data->result_array();
	}

	public function getPanjar($table)
	{
		$data = $this->db->get($table);
		return $data->result_array();
	}

	public function getKontrak($table)
	{
		$data = $this->db->get($table);
		return $data->result_array();
	}

	public function getUser($table)
	{
		$data = $this->db->get($table);
		return $data->result_array();
	}
}