<?php if (!defined('BASEPATH')) OR exit('No direct script access allowed');

class Home extends CI_Controller {
	public function homePage(){
		$data = $this->db->query('select * from tagihankontrak');
		foreach ($data => $result_array() as $tampil) {
			echo "Nomor 			: ".$tampil['idTagihanK']."<br />";
			echo "Uraian Tagihan 	: ".$tampil['uraian']."<br />";
			echo "Nilai 			: ".$tampil['nilai']."<br />";
			echo "Due Date 			: ".$tampil['dueDate']."<br />";
			echo "Nomor Kontrak 	: ".$tampil['noKontrak']."<br />";
			echo "Nomor PO 			: ".$tampil['noPO']."<br />";
			echo "Nomor PR			: ".$tampil['noPR']."<br />";
			echo "Nomor SA			: ".$tampil['noSA']."<br />";
			echo "Tanggal SA 		: ".$tampil['tglSA']."<br />";
			echo "Status 			: ".$tampil['status']."<br />";
		}
	}
}