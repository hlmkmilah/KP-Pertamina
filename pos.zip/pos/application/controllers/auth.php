<?php

class Auth extends CI_Controller
{
	public function index()
	{
		$this->load->view('login');
	}
	
	public function login()
	{
		$email = $this->input->post('email', true);
		$pass = $this->input->post('password', true);
		$cek = $this->mymodel->prosesLogin($email,$pass);
		$hasil = count($cek);
		//echo $hasil;
		if($hasil > 0)
		{
			$select = $this->db->get_where('user', array('email' => $email, 'password' => $pass))->row();
			$data = array('logged_in' => true, 'loger' => $select->Nama); //untuk munculin nama orang yg login
			$this->session->set_userdata($data);
			redirect('auth/homepage');
			//echo "login berhasil";
		}
		else
		{
			$this->session->set_flashdata('err', 'Wrong Email or Password!');
			//$this->load->view('index');
			redirect('auth/index');
			//echo "gagal login";
		}
	}

	public function homepage()
	{
		$this->dataTagihanK['hasilTagihanK'] = $this->mymodel->getTagihanK('tagihankontrak');
		$this->load->view('homepage', $this->dataTagihanK);
		// $this->dataTagihanNK['hasilTagihanNK'] = $this->mymodel->getTagihanNK('tagihannonkontrak');
		// $this->load->view('homepage', $this->dataTagihanNK);
		// $this->dataPanjar['hasilPanjar'] = $this->mymodel->getPanjar('panjar');
		// $this->load->view('homepage', $this->dataPanjar);
		// $this->dataKontrak['hasilKontrak'] = $this->mymodel->getKontrak('kontrak');
		// $this->load->view('homepage', $this->dataKontrak);
		// $this->dataUser['hasilUser'] = $this->mymodel->getUser('user');
		// $this->load->view('nyobahome', $this->dataUser);
	}

	public function logout()
	{
		$this->session->sess_destroy();
		//$this->load->view('index');
		redirect('auth/index');
	}
}